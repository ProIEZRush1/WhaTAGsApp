class AgoraConfig {
  static String token = '';
  static String appId = '01254a6c76514e4787628f4b6bdc1786';
  static String appcertificate = 'd4cafc0cc7d3466d9b51b9d604d971ff';
}
